from flask import Flask, flash, redirect,request, jsonify,render_template,send_file,url_for
import flask_excel as excel
import pandas as pd


app = Flask(__name__)

app.secret_key = 'random string'

@app.route("/", methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        f= request.form
        key_list=[]
        value_list=[]
        
        for key in f.keys():
            for value in f.getlist(key):
                key_list.append(key)
                value_list.append(value)
            print(key_list)
        print("Hey",value_list)
        
        if(key_list[0]=='course_code'):
            files = request.files['file']
            name=(files.filename).split('.')[1]
            name=value_list[0]+'.'+name
            print(name)
            files.save(name)  
            a=request.get_array(field_name='file')
            print("here",a)
            df = pd.DataFrame(a[1:], columns =a[0]) 
            flash('File successfully uploaded!')
            return redirect(url_for('upload_file'))

        elif(key_list[0]=='template'):
            path = 'templates.zip'
            return send_file(path, as_attachment=True)

        
        

    return render_template("admin.html")


if __name__ == "__main__":
    excel.init_excel(app)
    app.run(debug=True)